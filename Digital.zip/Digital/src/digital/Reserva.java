/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digital;

import java.awt.*;
// importa tudo q for usado do pacote digital Persona
import com.digitalpersona.*;
import com.digitalpersona.onetouch.DPFPCaptureFeedback;
import com.digitalpersona.onetouch.DPFPDataPurpose;
import com.digitalpersona.onetouch.DPFPFeatureSet;
import com.digitalpersona.onetouch.DPFPGlobal;
import com.digitalpersona.onetouch.DPFPSample;
import com.digitalpersona.onetouch.DPFPTemplate;
import com.digitalpersona.onetouch.capture.DPFPCapture;
import com.digitalpersona.onetouch.capture.event.DPFPDataAdapter;
import com.digitalpersona.onetouch.capture.event.DPFPDataEvent;
import com.digitalpersona.onetouch.capture.event.DPFPImageQualityAdapter;
import com.digitalpersona.onetouch.capture.event.DPFPImageQualityEvent;
import com.digitalpersona.onetouch.capture.event.DPFPReaderStatusAdapter;
import com.digitalpersona.onetouch.capture.event.DPFPSensorAdapter;
import com.digitalpersona.onetouch.capture.event.DPFPSensorEvent;
import com.digitalpersona.onetouch.processing.DPFPEnrollment;
import com.digitalpersona.onetouch.processing.DPFPFeatureExtraction;
import com.digitalpersona.onetouch.processing.DPFPImageQualityException;
import com.digitalpersona.onetouch.verification.DPFPVerification;
import com.digitalpersona.onetouch.verification.DPFPVerificationResult;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.regex.Matcher;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;


/**
 *
 * @author Gabriel
 */
public class Reserva extends javax.swing.JFrame {
    Bancodedados bd = new Bancodedados();
// tudo que sera chamado abaixo são classes abstratas e devem posteriormente virar um Objeto.
    //ler pagina 21 explica por que tem que chamar get capture e o creat capture

    public DPFPCapture Captura = DPFPGlobal.getCaptureFactory().createCapture();
    //usado para criar um template full bolado descrição dos metodos dessa classe na pagina 64;
    // assim como a DPFP capture  é uma classe abstrata tambem tem que criar um objeto apos o metodo get;
    public DPFPEnrollment Criador = DPFPGlobal.getEnrollmentFactory().createEnrollment();
    //Pagina 35 mostar um dos poucas coisas que foram realmente claras nessa documentaçao com exemplo e tudo.
    /* sera usado o Criador acima para verificaçao , pois a verificaçao criar um novo objeto(fora do banco de dados)
    e confere com o objeto que esta no banco de dados depois acredito que o objeto de digitas criado na verificação seja
    descartado .. esses 2 objetos se comparam com um if e diz o resultado foi positivo ou negativo*/
    public DPFPVerification Verificar = DPFPGlobal.getVerificationFactory().createVerification();
    public DPFPTemplate ModeloDigital;
    public DPFPTemplate Template_Property = ModeloDigital;
    public DPFPFeatureSet SetarDigital;
    ///recebe a digital
    public DPFPFeatureSet VerificarDigital;
    // usado na verificação


    /*Agora que o negocio começa. Seguinte isso tudo ai abaixo foi copíado e algumas coisas renomeadas para nossa interface
    esse metodos foram pegos da class captureform e verification form OBS galera isso n e cola porque o crowley (Tarley) disse que o Leitor tinha
    que oferecer os recursos pra nos . nosso dever é apenas entender oque os recursos fazer baseado na documentação lixosa que nos
    temos: os metodos estaram explicados abaixo
     */
    protected void iniciar() {
        Captura.addDataListener(new DPFPDataAdapter() {
            public void dataAcquired(final DPFPDataEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        Status("Sua digital Foi Capturada com Sucesso");
                        // Status aparecera no JTextfield
                        capturadigital(e.getSample());
                    }
                });
            }
        });
        Captura.addReaderStatusListener(new DPFPReaderStatusAdapter() {
            public void readerConnected(final DPFPReaderStatusAdapter e) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        Status("O leitor foi conectado.");
                    }
                });
            }

            public void readerDisconnected(final DPFPReaderStatusAdapter e) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        Status("O Leitor foi desconectado.");
                    }
                });
            }
        });
        Captura.addSensorListener(new DPFPSensorAdapter() {
            public void fingerTouched(final DPFPSensorEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        // O plano e aparecer isso quando colocar o dedo
                        Status("Dedo inserido no leitor.");
                    }
                });
            }

            @Override
            public void fingerGone(final DPFPSensorEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        Status("Dedo desconectado do leitor.");
                    }
                });
            }
        });
        Captura.addImageQualityListener(new DPFPImageQualityAdapter() {
            public void onImageQuality(final DPFPImageQualityEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        if (e.getFeedback().equals(DPFPCaptureFeedback.CAPTURE_FEEDBACK_GOOD)) {
                            Status("A qualidade da digital foi boa!");
                        } else {
                            Status("A qualidade da digital foi ruim!.");
                        }
                    }
                });
            }
        });
    }

    public DPFPFeatureSet Caracteristicas(
            //pagina 25 e 65
            DPFPSample sample, DPFPDataPurpose purpose) {
        DPFPFeatureExtraction Feature;
        Feature = DPFPGlobal.getFeatureExtractionFactory().createFeatureExtraction();
        {
            try {
                return Feature.createFeatureSet(sample, purpose);
            } catch (DPFPImageQualityException n) {
                return null;
            }
        }
    }

    public Image CriarImagem(DPFPSample sample) {
        return DPFPGlobal.getSampleConversionFactory().createImage(sample);
        ///novamente temos que criar um objeto no final pois é uma class abstrata.
    }
    public void serialize(){
        
    }

    public void Desenharimagem(Image image) {
        LabelImagemDigital.setIcon(new ImageIcon(
                image.getScaledInstance(LabelImagemDigital.getWidth(), LabelImagemDigital.getHeight(), Image.SCALE_DEFAULT)));
    }

    public void Status(String string) {
        Log.setText(string + "\n");
    }

    protected void start() {
        Captura.startCapture();
        setPrompt("Using the fingerprint reader, scan your fingerprint.");
    }

    protected void stop() {
        Captura.stopCapture();
    }

    public void setStatus(String string) {
        Log.setText(string);
    }

    public void setPrompt(String string) {
        Log.setText(string);
    }

    public DPFPTemplate getDPFPTemplate() {
        return ModeloDigital;
    }
    public void estadodadigital(){
        // segundo a documentação vai dizer quantas vezes voce deve escanear seu dedo para criar um fingerprint
        Criador.getFeaturesNeeded();
    }
    //metodo criado para sobrepor template caso voce tire e coloque a digital denovo;
    public void setTemplate(DPFPTemplate ModeloDigital) {
        DPFPTemplate antigo = this.ModeloDigital;
    }
    // volte a linha 136 para entender
    ///// esse DATA_PURPOSE_UNKNOWN AI EMBAIXO APARECEU NO ALT ESPAÇO tem no manual so nao sei pra q serve
    //public void capturadigital(DPFPSample Sample) throws DPFPImageQualityException {
    public void capturadigital(DPFPSample Sample) {
        SetarDigital = Caracteristicas(Sample, DPFPDataPurpose.DATA_PURPOSE_UNKNOWN);
        VerificarDigital = Caracteristicas(Sample, DPFPDataPurpose.DATA_PURPOSE_UNKNOWN);
        if (SetarDigital != null) {
            try {
                DPFPVerificationResult resultado = Verificar.verify(SetarDigital, ModeloDigital);
                if (resultado.isVerified()) {
                    Criador.addFeatures(SetarDigital);
                    Image image = CriarImagem(Sample);
                    Desenharimagem(image);
                    BTNautenticar.setEnabled(true);
                    BTNverificar.setEnabled(true);
                }
            } catch (DPFPImageQualityException e) {
                System.err.println("Erro >> " + e);
                BTNautenticar.setEnabled(false);
                BTNsalvar.setEnabled(false);

            }
                    finally{
                estadodadigital();

        switch (Criador.getTemplateStatus()) 
                {
            case TEMPLATE_STATUS_READY:
                //metodo pra para de capturar;
                stop();
                setTemplate(ModeloDigital);
                BTNautenticar.setEnabled(false);
                BTNverificar.setEnabled(false);
                BTNsalvar.setEnabled(true);
                break;
                /// para o switch caso entrar
                 
            case TEMPLATE_STATUS_FAILED:
                //limpa o template e pede pra por o dedo denovo
                Criador.clear();
                JOptionPane.showMessageDialog(null, "Falha ao capturar sua digital tente novamente");
                setTemplate(null);
                //metodo start criado acima pra começa captura denovo
                start();
                break;
                }
        }

        
                }
    }
    
        

    

    public Reserva() {
        initComponents();
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | UnsupportedLookAndFeelException e) {

        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel1 = new javax.swing.JPanel();
        LabelImagemDigital = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Log = new javax.swing.JTextArea();
        BTNautenticar = new javax.swing.JButton();
        BTNsalvar = new javax.swing.JButton();
        BTNverificar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        LabelImagemDigital.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(218, 218, 218)
                .addComponent(LabelImagemDigital, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(238, Short.MAX_VALUE))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LabelImagemDigital, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 127, Short.MAX_VALUE)
        );

        Log.setColumns(20);
        Log.setRows(5);
        jScrollPane1.setViewportView(Log);

        BTNautenticar.setText("indentificar");
        BTNautenticar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNautenticarActionPerformed(evt);
            }
        });

        BTNsalvar.setText("Salvar");
        BTNsalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNsalvarActionPerformed(evt);
            }
        });

        BTNverificar.setText("verificar");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(199, 199, 199)
                .addComponent(BTNautenticar)
                .addGap(18, 18, 18)
                .addComponent(BTNverificar)
                .addGap(29, 29, 29)
                .addComponent(BTNsalvar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BTNautenticar)
                    .addComponent(BTNsalvar)
                    .addComponent(BTNverificar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BTNautenticarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNautenticarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BTNautenticarActionPerformed

    private void BTNsalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNsalvarActionPerformed
        // TODO add your handling code here:
        public void salvarBD(){

    }//GEN-LAST:event_BTNsalvarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Reserva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Reserva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Reserva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Reserva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Reserva().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTNautenticar;
    private javax.swing.JButton BTNsalvar;
    private javax.swing.JButton BTNverificar;
    private javax.swing.JLabel LabelImagemDigital;
    private javax.swing.JTextArea Log;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel panel1;
    // End of variables declaration//GEN-END:variables
}
