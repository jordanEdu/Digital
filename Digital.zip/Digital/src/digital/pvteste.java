/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digital;

/**
 *
 * @author jordan
 */ import java.util.Random;
public class pvteste {
    public static int somam(int[][]mat){
        int soma=0;
        
        for(int i=0;i<2;i++){
            for(int j=0;j<5;j++){
                soma+=mat[i][j];
            }
        }
        
        return soma;
    }
    
    public static void main(String [] args){
        int matf[][] = new int [2][5];
        int somat=0;
        Random pre= new Random(100);
        
        for(int i=0;i<2;i++){
            for(int j=0;j<5;j++){
                matf[i][j]= pre.nextInt(40);
            }
            
        }
        for(int i=0;i<2;i++){
            for(int j=0;j<5;j++){
               System.out.print("["+matf[i][j]+"]");
            }
            System.out.println("");
        }
        somat=somam(matf);
        
        System.out.println("A soma de todos os numeros da matriz é: "+somat);
    }
}
